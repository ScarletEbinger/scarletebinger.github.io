Special credit to Rapphire and Arkadya!
Rapphire: Made my early True Survival graphics!
Arkadya: Showed me how to use custommodeldata!